import TsComponent from "./components/TsComponent";

function App() {
  return (
    <div className="App">
      {/* <Practice4></Practice4> */}

      <TsComponent />
    </div>
  );
}

export default App;
